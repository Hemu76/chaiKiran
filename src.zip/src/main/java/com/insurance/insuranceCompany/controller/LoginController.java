package com.insurance.insuranceCompany.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.model.OTPclass;
import com.insurance.insuranceCompany.service.LoginService;

@Controller
@RequestMapping("/insurance")
public class LoginController {
	LoginService logService;
	HttpSession session;

	@Autowired
	public LoginController(LoginService rep, HttpSession session) {
		this.logService = rep;
		this.session = session;
	}

	@GetMapping({ "/login", "insurancelogin", "/" })
	public String loginPage(Model model) {
		session.setAttribute("login", 0);
		model.addAttribute("login", new Login());
		return "loginPage";
	}

	@PostMapping("/login")
	public String loginSubmit(@ModelAttribute("login") Login lc, Model model) {
		System.out.println("came to this method  " + lc);
		Login check = logService.checkCredentials(lc);
		System.out.println(check);
		if (check.getRoleid() != 0) {
			session.setAttribute("login", check.getRoleid());
			return "dashboard";
		}
		model.addAttribute("login", new Login());
		model.addAttribute("errorMessage", "incorrect credentials");
		return "loginPage";
	}

	@GetMapping("/dashboard")
	public String dashboard(Model model) {
		Object lc = session.getAttribute("login");
		if (lc == null || (int) lc == 0) {
			model.addAttribute("noaccess", "you need to login first");
			model.addAttribute("login", new Login());
			return "loginPage";
		}
		return "dashboard";
	}

	@GetMapping("/forgotpassword")
	public String forgotpassword(Model model) {
		model.addAttribute("to", "");
		model.addAttribute("login", new OTPclass());
		return "forgotPasswordPage";
	}

	@GetMapping("/signout")
	public String signout(Model model) {
		session.setAttribute("login", 0);
		model.addAttribute("login", new Login());
		return "loginPage";
	}

}
