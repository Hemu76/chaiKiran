package com.insurance.insuranceCompany.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.contract.DiseaseRepositoryInterface;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.service.DiseaseService;

@Controller
@RequestMapping("/insurance")
public class DiseaseController {

	@Autowired
	DiseaseRepositoryInterface dri;
	@Autowired
	HttpSession session;
	@Autowired
	DiseaseService ds;
	@GetMapping("/getDisease")
	public String getAllDisease(Model model) {
		Object lc = session.getAttribute("login");
		if (lc == null || (int) lc == 0) {
			model.addAttribute("noaccess", "you need to login first");
			model.addAttribute("login", new Login());
			return "loginPage";
		}
		model.addAttribute("diseases", ds.getAllDisease());
		return "Disease";
	}

	@PostMapping("/addDisease")
	@ResponseBody
	public String addDisease(@RequestParam String name, String ICDCode, String Description) {
		String message = dri.addDisease(name, ICDCode, Description, "Active");
		return message;
	}

	@PostMapping("/editDisease")
	@ResponseBody
	public String editDisease(@RequestParam String name, String ICDCode, String Description, String Status,
			Model model) {
		String message = dri.editDisease(name, ICDCode, Description, Status);
		model.addAttribute("diseases", ds.getAllDisease());
		return message;
	}

	@PostMapping("/deleteDisease")
	@ResponseBody
	public String deleteDisease(@RequestParam String name) {
		String message = dri.deleteDisease(name);
		return message;
	}
}
