package com.insurance.insuranceCompany.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.repository.PaymentService;
import com.insurance.insuranceCompany.repository.SettlementRepository;
import com.insurance.insuranceCompany.service.LoginService;

@Controller
@RequestMapping("/insurance")
public class PaymentController {
	PaymentService ps;
	HttpSession session;
	LoginService perrep;

	@Autowired
	public PaymentController(SettlementRepository clr,
			HttpSession session, LoginService perrep, PaymentService ps) {
		this.session = session;
		this.perrep = perrep;
		this.ps = ps;
	}

	@GetMapping(value = "/getPayments")
	public String getAllTransaction(Model model) {
		Object lc = session.getAttribute("login");
		if (lc == null || (int) lc == 0) {
			model.addAttribute("noaccess", "you need to login first");
			model.addAttribute("login", new Login());
			return "loginPage";
		}
		int access = perrep.checkAccess((int) lc, "/getPayments");
		if (access == 1) {
			model.addAttribute("payments", ps.getAllTransaction());
			return "ViewPayments";
		}
		model.addAttribute("noaccess", "you dont have access to the payment section");
		return "dashboard";
	}
}
