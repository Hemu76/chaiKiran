package com.insurance.insuranceCompany.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.Dao.LoginDaoLayer;
import com.insurance.insuranceCompany.model.Login;

@Service
public class LoginService {
	@Autowired
	LoginDaoLayer dao;

	public Login checkCredentials(Login lc) {
		return dao.checkCredentials(lc);
	}

	public int resetpwd(String email, String pwd) {
		return dao.resetpwd(email, pwd);
	}

	public int checkAccess(int lc, String string) {
		return dao.checkAccess(lc, string);
	}
}
